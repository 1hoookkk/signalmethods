# Lurie Carillon Modal Analysis
[Elliot K. Canfield-Dafilou](https://ccrma.stanford.edu/~kermit) kermitATccrma.stanford.edu
[Kurt J. Werner](https://ccrma.stanford.edu/~kwerner/) k.wernerATqub.ac.uk
March, 2017

The data are presented several ways:

* **One-Bell-Per-File, Frequency-Sorted** where each bell's data are in separate files.  The columns are ordered FREQUENCY, AMPLITUDE, DECAY, PHASE, and each row corresponds to a different vibrational mode.

* **One-Bell-Per-File, Amplitude-Sorted** where each bell's data are in separate files.  The columns are ordered FREQUENCY, AMPLITUDE, DECAY, PHASE, and each row corresponds to a different vibrational mode.

* **Parameter-Specific-Files** where each modal parameter (frequency, amplitude, decay, and phase) is presented in a separate file. In this scheme, the data are organized as a matrix where each row corresponds to mode number and each column corresponds to an individual bell. When a bell has a small number of modes, the extra rows are padded with NaNs.  

**Note:** The second lowest bell does not physically exist in the Lurie Carillon and our numbering scheme takes this into account in jumping from bell number 0 to bell number 2 before continuing sequentially up to 59.  

These files are provided under a CREATIVE COMMONS LICENSE Attribution 4.0 International (CC BY 4.0)
